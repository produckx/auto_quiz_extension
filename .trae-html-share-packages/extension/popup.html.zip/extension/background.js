// Service worker: gọi OpenAI-compatible API và lưu dữ liệu cục bộ.

let agentState = {
  isRunning: false,
  activeTabId: null,
  nextDelay: 2
};

chrome.storage.session.get(["agentState"], (res) => {
  if (res?.agentState) agentState = { ...agentState, ...res.agentState };
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["nextDelay"], (data) => {
    if (data.nextDelay === undefined) chrome.storage.local.set({ nextDelay: 2 });
  });
});

const SYSTEM_PROMPT = `Bạn là trợ lý chuyên trả lời câu hỏi trắc nghiệm.

Quy tắc bắt buộc:
1. Phân tích câu hỏi và các lựa chọn cẩn thận.
2. Chọn đúng một đáp án phù hợp nhất.
3. Trả lời duy nhất theo JSON, không thêm văn bản bên ngoài:
{"answer":"A","reasoning":"Giải thích ngắn gọn bằng tiếng Việt","confidence":0.9}

answer phải là key của một lựa chọn; confidence nằm trong khoảng 0.0 đến 1.0.`;

function readLocal(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function writeLocal(values) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(values, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function inferProvider(baseUrl) {
  const url = (baseUrl || "").toLowerCase();
  if (url.includes("openrouter.ai")) return "openrouter";
  if (url.includes("localhost:11434") || url.includes("127.0.0.1:11434")) return "ollama";
  return "openai_compatible";
}

async function getConfig() {
  const { aiConfig } = await readLocal(["aiConfig"]);
  return aiConfig || null;
}

function getPublicConfig(config) {
  if (!config) return null;
  return { ...config, api_key: config.api_key ? "***" : null };
}

async function saveConfig(payload) {
  const previous = await getConfig();
  const baseUrl = (payload.base_url || "").trim().replace(/\/+$/, "");
  if (!baseUrl || !payload.model_name?.trim()) {
    throw new Error("Vui lòng nhập API URL và tên model.");
  }
  const url = new URL(baseUrl);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("API URL phải dùng HTTP hoặc HTTPS.");
  const isLoopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (url.protocol !== "https:" && !isLoopback) throw new Error("Endpoint ngoài máy cần dùng HTTPS để bảo vệ API key.");

  const enteredKey = (payload.api_key || "").trim();
  const config = {
    base_url: baseUrl,
    api_key: enteredKey && enteredKey !== "***" ? enteredKey : (previous?.api_key || ""),
    model_name: payload.model_name.trim(),
    provider: inferProvider(baseUrl),
    temperature: previous?.temperature ?? 0.3,
    max_tokens: previous?.max_tokens ?? 512,
    is_active: true
  };
  await writeLocal({ aiConfig: config });
  return config;
}

function normalizeText(text) {
  return (text || "").trim().toLowerCase().replace(/\s+/g, " ");
}

async function questionHash(question, options) {
  const normalized = `${normalizeText(question)}##${options.map(option => `${normalizeText(option.key)}:${normalizeText(option.text)}`).join("|")}`;
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(normalized));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

function extractMessageText(content) {
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) return content.map(part => part.text || "").join("\n").trim();
  return "";
}

function parseAnswer(rawText, options) {
  const match = rawText.match(/\{[\s\S]*?\}/);
  let answer = "";
  let reasoning = "";
  let confidence = 0.5;
  if (match) {
    try {
      const parsed = JSON.parse(match[0]);
      answer = String(parsed.answer || "").trim().toUpperCase();
      if (answer.length > 1 && "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".includes(answer[0])) {
        answer = answer[0];
      }
      reasoning = String(parsed.reasoning || "").trim();
      confidence = Number(parsed.confidence);
      if (!Number.isFinite(confidence)) confidence = 0.5;
    } catch (_) {}
  }
  if (!answer) {
    const fallback = rawText.toUpperCase().match(/(?:ĐÁP ÁN|ANSWER|CHỌN|SELECT|CORRECT)[:\s]+([A-Z0-9]+)/);
    if (fallback) answer = fallback[1];
  }
  if (!answer || !options.some(option => option.key.toUpperCase() === answer)) {
    throw new Error(`AI trả về đáp án không khớp lựa chọn: ${answer || "không xác định"}`);
  }
  return { answer_key: answer, reasoning: reasoning || rawText.slice(0, 300), confidence: Math.max(0, Math.min(1, confidence)) };
}

async function requestAnswer(payload, config) {
  const options = payload.options || [];
  const optionsText = options.map(option => `${option.key}. ${option.text}`).join("\n");
  const userText = `Câu hỏi: ${payload.question_text}\n\nCác lựa chọn:\n${optionsText}`;
  const userContent = payload.image_base64 && payload.question_type === "image"
    ? [
        { type: "text", text: userText },
        { type: "image_url", image_url: { url: `data:image/jpeg;base64,${payload.image_base64}` } }
      ]
    : userText;
  const endpoint = config.base_url.endsWith("/chat/completions")
    ? config.base_url
    : `${config.base_url}/chat/completions`;
  const headers = { "Content-Type": "application/json" };
  if (config.api_key) headers.Authorization = `Bearer ${config.api_key}`;

  let response;
  try {
    response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: config.model_name,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userContent }
        ],
        temperature: config.temperature ?? 0.3,
        max_tokens: config.max_tokens ?? 512
      })
    });
  } catch (error) {
    throw new Error(`Không kết nối được API ${endpoint}: ${error.message}`);
  }
  const responseText = await response.text();
  const isStream = (response.headers.get("content-type") || "").includes("text/event-stream") || responseText.trimStart().startsWith("data:");

  // Một số endpoint trả SSE dù không yêu cầu stream -> ghép các delta lại.
  let result = {};
  let rawText = "";
  if (isStream) {
    for (const line of responseText.split(/\r?\n/)) {
      if (!line.startsWith("data:")) continue;
      const chunk = line.slice(5).trim();
      if (!chunk || chunk === "[DONE]") continue;
      try {
        const parsed = JSON.parse(chunk);
        rawText += extractMessageText(parsed.choices?.[0]?.delta?.content);
      } catch (_) {}
    }
  } else {
    try { result = JSON.parse(responseText); } catch (_) {}
    rawText = extractMessageText(result.choices?.[0]?.message?.content) || result.choices?.[0]?.text?.trim() || "";
  }

  if (!response.ok) {
    const apiError = result.error?.message || (typeof result.error === "string" ? result.error : "") || result.detail;
    throw new Error(apiError || `API lỗi ${response.status}: ${response.statusText}${responseText ? ` — ${responseText.slice(0, 240)}` : ""}`);
  }
  if (!rawText) throw new Error(`AI trả về dữ liệu không đúng định dạng chat/completions.${responseText ? ` Phản hồi: ${responseText.slice(0, 240)}` : ""}`);
  return parseAnswer(rawText, options);
}

async function solveQuiz(payload) {
  const startedAt = Date.now();
  const options = payload.options || [];
  const hash = await questionHash(payload.question_text || "", options);
  const { qaCache = {} } = await readLocal(["qaCache"]);
  const cached = payload.use_cache !== false ? qaCache[hash] : null;

  if (cached) {
    cached.hit_count = (cached.hit_count || 0) + 1;
    cached.updated_at = new Date().toISOString();
    await writeLocal({ qaCache });
    const elapsed = Date.now() - startedAt;
    if (!payload.skip_history) await addHistory(payload, cached.answer_key, cached.model_name, elapsed);
    return {
      answer_key: cached.answer_key,
      reasoning: cached.reasoning || "Lấy từ cache cục bộ (câu hỏi đã từng giải).",
      confidence: 1,
      response_time_ms: elapsed,
      from_cache: true
    };
  }

  const config = await getConfig();
  if (!config?.base_url || !config?.model_name) throw new Error("Chưa cấu hình AI trong extension.");
  const answer = await requestAnswer(payload, config);
  const elapsed = Date.now() - startedAt;
  if (!payload.skip_cache) {
    const now = new Date().toISOString();
    const qaCache = (await readLocal(["qaCache"])).qaCache || {};
    qaCache[hash] = {
      id: Date.now(), question_hash: hash, question_text: payload.question_text,
      options, answer_key: answer.answer_key, reasoning: answer.reasoning,
      model_name: config.model_name, hit_count: 0, created_at: now, updated_at: now
    };
    await writeLocal({ qaCache });
  }
  if (!payload.skip_history) await addHistory(payload, answer.answer_key, config.model_name, elapsed);
  return { ...answer, response_time_ms: elapsed, from_cache: false };
}

async function addHistory(payload, answerKey, modelName, responseTime) {
  const { quizHistory = [] } = await readLocal(["quizHistory"]);
  quizHistory.push({
    id: Date.now() + Math.random(), website_url: payload.website_url,
    question_text: payload.question_text, question_type: payload.question_type || "text",
    options: payload.options || [], selected_answer: answerKey, correct_answer: null,
    is_correct: null, ai_model_used: modelName || null, response_time_ms: responseTime,
    created_at: new Date().toISOString()
  });
  await writeLocal({ quizHistory });
}

async function getHistory(payload = {}) {
  const { quizHistory = [] } = await readLocal(["quizHistory"]);
  const filter = (payload.url || "").toLowerCase();
  const records = quizHistory
    .filter(item => !filter || (item.website_url || "").toLowerCase().includes(filter))
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const pageSize = payload.page_size || 8;
  const page = payload.page || 1;
  return {
    total: records.length, page, page_size: pageSize,
    total_pages: Math.ceil(records.length / pageSize),
    items: records.slice((page - 1) * pageSize, page * pageSize)
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const { action, payload } = request;
  const respond = async () => {
    switch (action) {
      case "PING_WORKER":
        return { success: true };
      case "CHECK_LOCAL_STATUS": {
        const config = await getConfig();
        return { success: true, data: { configured: Boolean(config?.base_url && config?.model_name) } };
      }
      case "SOLVE_QUIZ_API":
        return { success: true, data: await solveQuiz(payload) };
      case "GET_CONFIG": {
        const config = await getConfig();
        return { success: true, data: getPublicConfig(config) };
      }
      case "SAVE_CONFIG":
        return { success: true, data: getPublicConfig(await saveConfig(payload)) };
      case "GET_HISTORY":
        return { success: true, data: await getHistory(payload) };
      case "DELETE_HISTORY_ITEM": {
        const { quizHistory = [] } = await readLocal(["quizHistory"]);
        const kept = quizHistory.filter(item => String(item.id) !== String(payload.id));
        await writeLocal({ quizHistory: kept });
        return { success: true };
      }
      case "UPDATE_AUTO_STATE": {
        agentState.isRunning = Boolean(request.isRunning);
        if (sender.tab) agentState.activeTabId = sender.tab.id;
        chrome.storage.session.set({ agentState });
        chrome.runtime.sendMessage({ action: "BROADCAST_AUTO_STATE", isRunning: agentState.isRunning }).catch(() => {});
        return { success: true, isRunning: agentState.isRunning };
      }
      case "GET_AGENT_STATUS":
        return { isRunning: agentState.isRunning, activeTabId: agentState.activeTabId };
      case "RESUME_STATE": {
        const senderTabId = sender.tab ? sender.tab.id : null;
        return { shouldRun: Boolean(agentState.isRunning && senderTabId !== null && agentState.activeTabId === senderTabId) };
      }
      default:
        return undefined;
    }
  };

  respond().then(result => {
    if (result !== undefined) sendResponse(result);
  }).catch(error => sendResponse({ success: false, error: error.message || "Lỗi xử lý yêu cầu." }));
  return true;
});
